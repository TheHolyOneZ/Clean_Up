import os
import shutil
import ctypes
import sys
import tkinter as tk





def loesche_ordner_inhalt(ordner):
    if os.path.exists(ordner):
        for root, dirs, files in os.walk(ordner):
            for file in files:
                try:
                    os.remove(os.path.join(root, file))
                except Exception:
                    pass
            for dir in dirs:
                try:
                    shutil.rmtree(os.path.join(root, dir))
                except Exception:
                    pass

def loesche_temp_und_papierkorb():
    loesche_ordner_inhalt(os.getenv('TEMP'))
    loesche_ordner_inhalt(r'C:\Windows\Temp')
    ctypes.windll.shell32.SHEmptyRecycleBinW(None, None, 3)
    sys.exit()

if __name__ == "__main__":
    loesche_temp_und_papierkorb()
